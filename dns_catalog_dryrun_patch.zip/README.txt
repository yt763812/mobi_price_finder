DNS Беларусь — только диагностика смартфонов.
Добавьте dns_catalog_dryrun.py в корень GitHub-проекта.
Сначала: /app/.venv/bin/python -u dns_catalog_dryrun.py --max-pages 2 --json /tmp/dns_2pages.json
Если получилось: /app/.venv/bin/python -u dns_catalog_dryrun.py --max-pages 50 --json /tmp/dns_full.json
Скрипт не использует базу, бота и не сохраняет поставщиков.
Если HTTP 403 — сбор завершается. Не пытайтесь запускать полный обход до успешной проверки.
Важно: значения цен являются кандидатами из блока товара, а не доказанной итоговой ценой продажи.
